// import React from 'react'
// import AddInHouseProduct from './AddProduct'
// import InHouseProductPricing from './InHouseProductPricing'
// import ProductVariationSetup from './ProductVariationSetup'
// import ProductImagesSection from './ProductImageSelection/ProductImagesSection'

// const MainHouseAddProduct = () => {
//   return (
//     <div className='p-7'>
//      <AddInHouseProduct />
//      <InHouseProductPricing />
//      <ProductVariationSetup /> 
//      <ProductImagesSection />   
//     </div>
//   )
// }

// export default MainHouseAddProduct