import React from 'react'
import OrderStatistic from './OrderStatistic/OrderStatistic'

const OrderStatic = () => {
  return (
    <div className=''>
       <div className="col-8">
        <OrderStatistic />
        </div>    
       <div className="col-4">any thing</div>    
    </div>
  )
}

export default OrderStatic