import React from 'react'
import Index from './Index'
import Ticket_Support from './Ticket_Support'

const Health_Support = () => {
  return (
    <>
    <Index/>
    
    </>
  )
}

export default Health_Support
