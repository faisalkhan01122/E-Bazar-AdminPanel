import React from 'react'

const PaymentOption = () => {
  return (
    <div>PaymentOption</div>
  )
}

export default PaymentOption