const ImageApiUrl = 'https://lionfish-app-tdhk5.ondigitalocean.app';
// const ApiUrl = 'http://localhost:3000/api/';
export default ImageApiUrl;
