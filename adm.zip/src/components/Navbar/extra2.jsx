

// <div class="content container-fluid snipcss-AO86T">
//     <div class="mb-3">
//         <h2 class="h1 mb-0 text-capitalize d-flex gap-2">
//             <img src="https://6valley.6amtech.com/public/assets/back-end/img/inhouse-product-list.png" alt=""> In House Product List <span class="badge badge-soft-dark radius-50 fz-14 ml-1">16</span>
//         </h2>
//     </div>
//     <div class="card">
//         <div class="card-body">
//             <form action="https://6valley.6amtech.com/admin/products/list/in-house" method="GET">
//                 <input type="hidden" value="" name="status">
//                 <div class="row gx-2">
//                     <div class="col-12">
//                         <h4 class="mb-3">Filter Products</h4>
//                     </div>
//                     <div class="col-sm-6 col-lg-4 col-xl-3">
//                         <div class="form-group">
//                             <label class="title-color" for="store">Brand</label>
//                             <select name="brand_id" class="js-select2-custom form-control text-capitalize select2-hidden-accessible" data-select2-id="1" tabindex="-1" aria-hidden="true">
//                                 <option value="" selected="" data-select2-id="3">All Brands</option>
//                                 <option value="1" data-select2-id="4">i Bird</option>
//                                 <option value="4" data-select2-id="5">Agron</option>
//                                 <option value="5" data-select2-id="6">Triangle</option>
//                                 <option value="6" data-select2-id="7">Estro</option>
//                                 <option value="7" data-select2-id="8">Ohoenix</option>
//                                 <option value="8" data-select2-id="9">Waltro</option>
//                                 <option value="9" data-select2-id="10">JK</option>
//                                 <option value="12" data-select2-id="11">Fashion</option>
//                                 <option value="13" data-select2-id="12">S.Cube</option>
//                                 <option value="14" data-select2-id="13">Estha dot</option>
//                                 <option value="17" data-select2-id="14">Digital Product</option>
//                             </select><span class="select2 select2-container select2-container--default style-dRY8L" dir="ltr" data-select2-id="2" id="style-dRY8L"><span class="selection"><span class="select2-selection custom-select" role="combobox" aria-haspopup="true" aria-expanded="false" tabindex="0" aria-disabled="false" aria-labelledby="select2-brand_id-l9-container"><span class="select2-selection__rendered" id="select2-brand_id-l9-container" role="textbox" aria-readonly="true" title="All Brands"><span>All Brands</span></span><span class="select2-selection__arrow" role="presentation"><b role="presentation"></b></span></span></span><span class="dropdown-wrapper" aria-hidden="true"></span></span>
//                         </div>
//                     </div>
//                     <div class="col-sm-6 col-lg-4 col-xl-3">
//                         <div class="form-group">
//                             <label for="name" class="title-color">Category</label>
//                             <select class="js-select2-custom form-control action-get-request-onchange select2-hidden-accessible" name="category_id" data-url-prefix="https://6valley.6amtech.com/admin/products/get-categories?parent_id=" data-element-id="sub-category-select" data-element-type="select" data-select2-id="15" tabindex="-1" aria-hidden="true">
//                                 <option value="" selected="" disabled="" data-select2-id="17">Select category</option>
//                                 <option value="11" data-select2-id="18"> Home Improvement &amp; Tools </option>
//                                 <option value="12" data-select2-id="19"> Toys , Kids &amp; Babies </option>
//                                 <option value="13" data-select2-id="20"> Men's fashion </option>
//                                 <option value="14" data-select2-id="21"> Outdoor Fun &amp; Sports </option>
//                                 <option value="15" data-select2-id="22"> Women's fashion </option>
//                                 <option value="16" data-select2-id="23"> ebook </option>
//                                 <option value="24" data-select2-id="24"> Jewelry &amp; Watches </option>
//                                 <option value="25" data-select2-id="25"> Beauty, Health &amp; Hair </option>
//                                 <option value="26" data-select2-id="26"> Mobile Accessories </option>
//                                 <option value="27" data-select2-id="27"> Computer, Office &amp; Security </option>
//                                 <option value="28" data-select2-id="28"> Phones &amp; Telecom </option>
//                                 <option value="34" data-select2-id="29"> Home, Pet &amp; Appliances </option>
//                                 <option value="39" data-select2-id="30"> Bags &amp; Shoes </option>
//                             </select><span class="select2 select2-container select2-container--default style-4jLrX" dir="ltr" data-select2-id="16" id="style-4jLrX"><span class="selection"><span class="select2-selection custom-select" role="combobox" aria-haspopup="true" aria-expanded="false" tabindex="0" aria-disabled="false" aria-labelledby="select2-category_id-x3-container"><span class="select2-selection__rendered" id="select2-category_id-x3-container" role="textbox" aria-readonly="true" title="Select category"><span>Select category</span></span><span class="select2-selection__arrow" role="presentation"><b role="presentation"></b></span></span></span><span class="dropdown-wrapper" aria-hidden="true"></span></span>
//                         </div>
//                     </div>
//                     <div class="col-sm-6 col-lg-4 col-xl-3">
//                         <div class="form-group">
//                             <label for="name" class="title-color">Sub Category</label>
//                             <select class="js-select2-custom form-control action-get-request-onchange select2-hidden-accessible" name="sub_category_id" id="sub-category-select" data-url-prefix="https://6valley.6amtech.com/admin/products/get-categories?parent_id=" data-element-id="sub-sub-category-select" data-element-type="select" data-select2-id="sub-category-select" tabindex="-1" aria-hidden="true">
//                                 <option value="" selected="" disabled="" data-select2-id="32">Select Sub Category</option>
//                             </select><span class="select2 select2-container select2-container--default style-f1tgi" dir="ltr" data-select2-id="31" id="style-f1tgi"><span class="selection"><span class="select2-selection custom-select" role="combobox" aria-haspopup="true" aria-expanded="false" tabindex="0" aria-disabled="false" aria-labelledby="select2-sub-category-select-container"><span class="select2-selection__rendered" id="select2-sub-category-select-container" role="textbox" aria-readonly="true" title="Select Sub Category"><span>Select Sub Category</span></span><span class="select2-selection__arrow" role="presentation"><b role="presentation"></b></span></span></span><span class="dropdown-wrapper" aria-hidden="true"></span></span>
//                         </div>
//                     </div>
//                     <div class="col-sm-6 col-lg-4 col-xl-3">
//                         <div class="form-group">
//                             <label for="name" class="title-color">Sub Sub Category</label>
//                             <select class="js-select2-custom form-control select2-hidden-accessible" name="sub_sub_category_id" id="sub-sub-category-select" data-select2-id="sub-sub-category-select" tabindex="-1" aria-hidden="true">
//                                 <option value="" selected="" disabled="" data-select2-id="34">Select Sub Sub Category</option>
//                             </select><span class="select2 select2-container select2-container--default style-D58pH" dir="ltr" data-select2-id="33" id="style-D58pH"><span class="selection"><span class="select2-selection custom-select" role="combobox" aria-haspopup="true" aria-expanded="false" tabindex="0" aria-disabled="false" aria-labelledby="select2-sub-sub-category-select-container"><span class="select2-selection__rendered" id="select2-sub-sub-category-select-container" role="textbox" aria-readonly="true" title="Select Sub Sub Category"><span>Select Sub Sub Category</span></span><span class="select2-selection__arrow" role="presentation"><b role="presentation"></b></span></span></span><span class="dropdown-wrapper" aria-hidden="true"></span></span>
//                         </div>
//                     </div>
//                     <div class="col-12">
//                         <div class="d-flex gap-3 justify-content-end">
//                             <a href="https://6valley.6amtech.com/admin/products/list/in-house" class="btn btn-secondary px-5"> Reset </a>
//                             <button type="submit" class="btn btn--primary px-5 action-get-element-type"> Show data </button>
//                         </div>
//                     </div>
//                 </div>
//             </form>
//         </div>
//     </div>
//     <div class="row mt-20">
//         <div class="col-md-12">
//             <div class="card">
//                 <div class="px-3 py-4">
//                     <div class="row align-items-center">
//                         <div class="col-lg-4">
//                             <form action="https://6valley.6amtech.com/admin/products/list/in-house" method="GET">
//                                 <div class="input-group input-group-custom input-group-merge">
//                                     <div class="input-group-prepend">
//                                         <div class="input-group-text">
//                                             <i class="tio-search"></i>
//                                         </div>
//                                     </div>
//                                     <input id="datatableSearch_" type="search" name="searchValue" class="form-control" placeholder="Search by Product Name" aria-label="Search orders" value="">
//                                     <input type="hidden" value="" name="status">
//                                     <button type="submit" class="btn btn--primary">Search</button>
//                                 </div>
//                             </form>
//                         </div>
//                         <div class="col-lg-8 mt-3 mt-lg-0 d-flex flex-wrap gap-3 justify-content-lg-end">
//                             <div>
//                                 <button type="button" class="btn btn-outline--primary" data-toggle="dropdown">
//                                     <i class="tio-download-to"></i> Export <i class="tio-chevron-down"></i>
//                                 </button>
//                                 <ul class="dropdown-menu dropdown-menu-right">
//                                     <li>
//                                         <a class="dropdown-item" href="https://6valley.6amtech.com/admin/products/export-excel/in-house?brand_id=&amp;searchValue=&amp;category_id=&amp;sub_category_id=&amp;sub_sub_category_id=&amp;seller_id=&amp;status=">
//                                             <img width="14" src="https://6valley.6amtech.com/public/assets/back-end/img/excel.png" alt=""> Excel </a>
//                                     </li>
//                                 </ul>
//                             </div>
//                             <a href="https://6valley.6amtech.com/admin/products/stock-limit-list/in_house" class="btn btn-info">
//                                 <span class="text">Limited Stocks</span>
//                             </a>
//                             <a href="https://6valley.6amtech.com/admin/products/add" class="btn btn--primary">
//                                 <i class="tio-add"></i>
//                                 <span class="text">Add new product</span>
//                             </a>
//                         </div>
//                     </div>
//                 </div>
//                 <div class="table-responsive">
//                     <table id="datatable" class="table table-hover table-borderless table-thead-bordered table-nowrap table-align-middle card-table w-100 text-start">
//                         <thead class="thead-light thead-50 text-capitalize">
//                             <tr>
//                                 <th>SL</th>
//                                 <th>Product Name</th>
//                                 <th class="text-center">Product Type</th>
//                                 <th class="text-center">Unit price</th>
//                                 <th class="text-center">Show as featured</th>
//                                 <th class="text-center">Active status</th>
//                                 <th class="text-center">Action</th>
//                             </tr>
//                         </thead>
//                         <tbody>
//                             <tr>
//                                 <th scope="row">1</th>
//                                 <td>
//                                     <a href="https://6valley.6amtech.com/admin/products/view/in-house/45" class="media align-items-center gap-2">
//                                         <img src="https://6valley.6amtech.com/storage/app/public/product/thumbnail/2023-06-13-64883e708db4e.png" class="avatar border" alt="">
//                                         <span class="media-body title-color hover-c1"> Create Your Own Busi... </span>
//                                     </a>
//                                 </td>
//                                 <td class="text-center"> Digital </td>
//                                 <td class="text-center"> $500.00 </td>
//                                 <td class="text-center">
//                                     <form action="https://6valley.6amtech.com/admin/products/featured-status" method="post" id="product-featured45-form">
//                                         <input type="hidden" name="_token" value="ze0GWUJdOFTygsn8ecBJ5eLPHaw8OO6oqUnD3tx4" autocomplete="off"> <input type="hidden" name="id" value="45">
//                                         <label class="switcher mx-auto">
//                                             <input type="checkbox" class="switcher_input toggle-switch-message" name="status" id="product-featured45" value="1" data-modal-id="toggle-status-modal" data-toggle-id="product-featured45" data-on-image="product-status-on.png" data-off-image="product-status-off.png" data-on-title="Want to Add Create Your Own Business pdf version-2 To the featured section" data-off-title="Want to Remove Create Your Own Business pdf version-2 To the featured section" data-on-message="<p>If enabled this product will be shown in the featured product on the website and customer app</p>" data-off-message="<p>If disabled this product will be removed from the featured product section of the website and customer app</p>">
//                                             <span class="switcher_control"></span>
//                                         </label>
//                                     </form>
//                                 </td>
//                                 <td class="text-center">
//                                     <form action="https://6valley.6amtech.com/admin/products/status-update" method="post" data-from="product-status" id="product-status45-form" class="admin-product-status-form">
//                                         <input type="hidden" name="_token" value="ze0GWUJdOFTygsn8ecBJ5eLPHaw8OO6oqUnD3tx4" autocomplete="off"> <input type="hidden" name="id" value="45">
//                                         <label class="switcher mx-auto">
//                                             <input type="checkbox" class="switcher_input toggle-switch-message" name="status" id="product-status45" value="1" checked="" data-modal-id="toggle-status-modal" data-toggle-id="product-status45" data-on-image="product-status-on.png" data-off-image="product-status-off.png" data-on-title="Want to Turn ON Create Your Own Business pdf version-2 Status" data-off-title="Want to Turn OFF Create Your Own Business pdf version-2 Status" data-on-message="<p>If enabled this product will be available on the website and customer app</p>" data-off-message="<p>If disabled this product will be hidden from the website and customer app</p>">
//                                             <span class="switcher_control"></span>
//                                         </label>
//                                     </form>
//                                 </td>
//                                 <td>
//                                     <div class="d-flex justify-content-center gap-2">
//                                         <a class="btn btn-outline-info btn-sm square-btn" title="Barcode" href="https://6valley.6amtech.com/admin/products/barcode/45">
//                                             <i class="tio-barcode"></i>
//                                         </a>
//                                         <a class="btn btn-outline-info btn-sm square-btn" title="View" href="https://6valley.6amtech.com/admin/products/view/in-house/45">
//                                             <i class="tio-invisible"></i>
//                                         </a>
//                                         <a class="btn btn-outline--primary btn-sm square-btn" title="Edit" href="https://6valley.6amtech.com/admin/products/update/45">
//                                             <i class="tio-edit"></i>
//                                         </a>
//                                         <span class="btn btn-outline-danger btn-sm square-btn delete-data" title="Delete" data-id="product-45">
//                                             <i class="tio-delete"></i>
//                                         </span>
//                                     </div>
//                                     <form action="https://6valley.6amtech.com/admin/products/delete/45" method="post" id="product-45">
//                                         <input type="hidden" name="_token" value="ze0GWUJdOFTygsn8ecBJ5eLPHaw8OO6oqUnD3tx4" autocomplete="off"> <input type="hidden" name="_method" value="delete">
//                                     </form>
//                                 </td>
//                             </tr
// >


//     <tr>
//         <th>
//             <Link>
//             <a href="@">
//                 <i class="tio-arrow-right-thick"></i>
//                 <span>Next</span>
//                 <span>Previouse</span>
                 
//             </a>
//             </Link>
//         </th>
//     </tr>