// import React from 'react';
// import LanguageSelector from './LanguageSelector';
// import UserProfile from './UserProfile';
// import './Header.css'
// const Header = () => {
//     return (
//         <header id="header" className="navbar navbar-expand-lg navbar-fixed navbar-height navbar-flush navbar-container shadow snipcss-f1Pz9">
//             <div className="navbar-nav-wrap">
//                 <div className="navbar-brand-wrapper d-none d-sm-block d-xl-none">
//                     <a className="navbar-brand" href="https://6valley.6amtech.com/admin/dashboard" aria-label="">
//                         <img className="navbar-brand-logo" src="https://6valley.6amtech.com/storage/app/public/company/2023-06-13-648845d83c293.png" alt="Logo" />
//                         <img className="navbar-brand-logo-mini" src="https://6valley.6amtech.com/storage/app/public/company/2023-06-13-648845d83c293.png" alt="Logo" />
//                     </a>
//                 </div>
//                 <div className="navbar-nav-wrap-content-left">
//                     <button type="button" className="js-navbar-vertical-aside-toggle-invoker close mr-3 d-xl-none">
//                         <i className="tio-first-page navbar-vertical-aside-toggle-short-align"></i>
//                         <i className="tio-last-page navbar-vertical-aside-toggle-full-align" data-template="<div class=&quot;tooltip d-none d-sm-block&quot; role=&quot;tooltip&quot;><div class=&quot;arrow&quot;></div><div class=&quot;tooltip-inner&quot;></div></div>" data-toggle="tooltip" data-placement="right" title="" data-original-title="Expand"></i>
//                     </button>
//                 </div>
//                 <div className="navbar-nav-wrap-content-right style-bxJ7g" id="style-bxJ7g">
//                     <ul className="navbar-nav align-items-center flex-row gap-xl-16px">
//                         <LanguageSelector />
//                         <UserProfile />
//                     </ul>
//                 </div>
//             </div>
//         </header>
//     );
// }

// export default Header;



