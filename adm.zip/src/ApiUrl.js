const ApiUrl = 'https://lionfish-app-tdhk5.ondigitalocean.app/api/';
// const ApiUrl = 'http://localhost:3000/api/';
export default ApiUrl;
